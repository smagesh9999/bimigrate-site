# Power BI Desktop Migration Checklist

**Workbook:** sample_workbook.twb  
**SKU:** BI Migrate Desktop Pack (1.0.0)  
**Complexity:** Unknown (score ?)  
**Gap summary:** exact=0 · approx=0 · unsupported=0

## Included in this pack
- [x] Assessment PDF
- [x] Inventory JSON
- [x] Gap matrix JSON
- [x] Semantic model YAML / JSON (SSoT)
- [x] TMSL JSON (open-friendly model script)
- [x] DAX measures list
- [x] This checklist

## Not included (Desktop Pack)
- [ ] Full PBIP report pages / visuals (Enterprise / later SKU)
- [ ] Fabric workspace deploy
- [ ] Screenshot refs (generate locally with Tableau Desktop exporter)

## Your Desktop steps
1. Review `assessment.pdf` and `gap_matrix.json`.
2. Import or recreate tables from your data source (or Hyper exports if you have them).
3. Create / paste measures from `dax_measures.json` into Power BI Desktop Model view; fix any `approx` / `unsupported` items.
4. Build report pages manually using `inventory.json` dashboards/worksheets as the map.
5. Optional visual QA: run `python scripts/export_tableau_screenshots.py --workbook "<your.twbx>"` and compare to PBIX pages (±8px).
6. When ready for managed delivery, request a Migration quote (upsell).

## Definition of done (Desktop Pack buyer)
- [ ] All Low-risk measures compile in Desktop
- [ ] Every `approx`/`unsupported` gap has a decision (fix / redesign / defer)
- [ ] Page inventory matches Tableau dashboard list
