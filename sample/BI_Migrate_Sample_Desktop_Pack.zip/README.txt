BI Migrate — BI Migrate Desktop Pack
================================

Workbook: sample_workbook.twb
Product: desktop_pack v1.0.0
Paid SKU (list): ₹2999 per workbook

This pack helps you migrate to **Power BI Desktop**. It is an assessment + model starter,
NOT a finished .pbix/.pbip with pixel-perfect visuals.

Files
-----
README.txt                 This file
assessment.pdf             Diagnostic migration report
inventory.json             Sheets, dashboards, tables, measures overview
gap_matrix.json            exact / approx / unsupported heuristics
semantic_model.yaml        Declarative model (SSoT)
semantic_model.json        Same model as JSON
tmsl.json                  TMSL createOrReplace payload (reference)
dax_measures.json          Measure name → DAX draft
migration_checklist.md     Step-by-step Desktop checklist
manifest.json              Pack metadata

Roadmap
-------
Desktop Pack (this) → paid self-checkout now
Enterprise Pack later → Fabric deploy, automated report pages, REST visual baselines
